package view;

/**
 * This interface represents the view for the event panel.
 */
public interface IEventPanelView {
}
