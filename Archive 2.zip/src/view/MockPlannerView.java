package view;

import java.util.List;

import model.Event;

/**
 * This class represents a mock planner view for testing purposes.
 * It implements the IPlannerView interface.
 */
public class MockPlannerView implements IPlannerView {

  @Override
  public void updateSchedule(List<Event> events) {
    System.out.println("Events:");
    for (Event event : events) {
      System.out.println(event);
    }
  }

  @Override
  public void setListener(PlannerViewListener listener) {
    System.out.println("Listener set");
  }

  @Override
  public void showError(String message) {
    System.out.println(message);
  }

  @Override
  public void setVisible(boolean visible) {
  }
}
